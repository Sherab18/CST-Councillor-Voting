
<footer class="footer">
	<hr/>
&copy2021. Developed by Group05
<br/>
E-Voting System.
<br/>

</footer>
