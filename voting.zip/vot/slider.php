<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/SliderCss.css">
</head>
<body>

</body>
</html>
<div id="slider">
	<figure>
<img src="img/vote1.jpg">
<img src="img/votee.jpg">
<img src="img/bg.png">

    </figure>
</div>
